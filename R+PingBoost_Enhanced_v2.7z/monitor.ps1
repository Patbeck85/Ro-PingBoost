# ==========================================
# RAGNAROK+ PINGBOOST ENHANCED v2.0
# ==========================================
$CONFIG = @{
    ServerAddress  = "138.201.124.56"
    ServerPort     = 5121
    ProcessName    = "Ragnarokplus"
    PingInterval   = 3000
    MaxHistorySize = 100
}

# Wait for Launcher Countdown (30s)
Start-Sleep -Seconds 30

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$mtuConfigFile = Join-Path $scriptPath "mtu.cfg"
$MTU = if (Test-Path $mtuConfigFile) { (Get-Content $mtuConfigFile).Trim() } else { "1500" }

# ==========================================
# BACKUP STORAGE (für Rollback)
# ==========================================
$script:originalValues = @{}

# ==========================================
# 2. WAIT FOR GAME (Up to 2 Minutes)
# ==========================================
$retryCount = 0
while (-not (Get-Process -Name $CONFIG.ProcessName -ErrorAction SilentlyContinue) -and $retryCount -lt 60) {
    Start-Sleep -Seconds 2
    $retryCount++
}

if (-not (Get-Process -Name $CONFIG.ProcessName -ErrorAction SilentlyContinue)) {
    exit 
}

# ==========================================
# 3. STATS & HELPER FUNCTIONS
# ==========================================
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
$sig = '[DllImport("user32.dll", SetLastError=true)] public static extern bool DestroyIcon(IntPtr hIcon);'
$helper = Add-Type -MemberDefinition $sig -Name "IconHelper" -PassThru

# Stats Tracking Variables
$script:latencyHistory = @()
$script:totalChecks = 0
$script:failedChecks = 0
$script:minLatency = [int]::MaxValue
$script:maxLatency = 0
$script:lastLatency = 0
$script:optimizationsApplied = @()

function Write-Log {
    param([string]$Message, [string]$Type = "INFO")
    $timestamp = Get-Date -Format "HH:mm:ss"
    $logFile = Join-Path $scriptPath "pingboost.log"
    "[$timestamp] [$Type] $Message" | Out-File -FilePath $logFile -Append -Encoding Default
}

# ==========================================
# STUFE 1 OPTIMIERUNGEN
# ==========================================

function Set-NetworkThrottling {
    param([bool]$Enable)
    $path = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
    try {
        if ($Enable) {
            # Backup original value
            $current = Get-ItemProperty -Path $path -Name "NetworkThrottlingIndex" -ErrorAction SilentlyContinue
            if ($current) {
                $script:originalValues['NetworkThrottlingIndex'] = $current.NetworkThrottlingIndex
            } else {
                $script:originalValues['NetworkThrottlingIndex'] = 10  # Windows default
            }
            
            # Disable throttling
            Set-ItemProperty -Path $path -Name "NetworkThrottlingIndex" -Value 0xffffffff -Type DWord -Force
            Write-Log "NetworkThrottlingIndex deaktiviert" "SUCCESS"
            $script:optimizationsApplied += "Network Throttling disabled"
        } else {
            # Restore original
            if ($script:originalValues.ContainsKey('NetworkThrottlingIndex')) {
                Set-ItemProperty -Path $path -Name "NetworkThrottlingIndex" -Value $script:originalValues['NetworkThrottlingIndex'] -Type DWord -Force
                Write-Log "NetworkThrottlingIndex wiederhergestellt" "RESTORE"
            }
        }
    } catch {
        Write-Log "NetworkThrottling Fehler: $_" "ERROR"
    }
}

function Set-SystemResponsiveness {
    param([bool]$Enable)
    $path = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
    try {
        if ($Enable) {
            # Backup
            $current = Get-ItemProperty -Path $path -Name "SystemResponsiveness" -ErrorAction SilentlyContinue
            if ($current) {
                $script:originalValues['SystemResponsiveness'] = $current.SystemResponsiveness
            } else {
                $script:originalValues['SystemResponsiveness'] = 20  # Windows default
            }
            
            # Maximize foreground responsiveness
            Set-ItemProperty -Path $path -Name "SystemResponsiveness" -Value 0 -Type DWord -Force
            Write-Log "SystemResponsiveness auf 0 gesetzt" "SUCCESS"
            $script:optimizationsApplied += "System Responsiveness maximized"
        } else {
            # Restore
            if ($script:originalValues.ContainsKey('SystemResponsiveness')) {
                Set-ItemProperty -Path $path -Name "SystemResponsiveness" -Value $script:originalValues['SystemResponsiveness'] -Type DWord -Force
                Write-Log "SystemResponsiveness wiederhergestellt" "RESTORE"
            }
        }
    } catch {
        Write-Log "SystemResponsiveness Fehler: $_" "ERROR"
    }
}

function Set-QoSPolicy {
    param([bool]$Enable)
    $policyName = "RagnarokPlus_QoS"
    try {
        if ($Enable) {
            # Remove existing policy if exists
            Remove-NetQosPolicy -Name $policyName -Confirm:$false -ErrorAction SilentlyContinue
            
            # Create QoS policy for game traffic
            $policy = New-NetQosPolicy -Name $policyName `
                -IPDstPortMatchCondition $CONFIG.ServerPort `
                -IPProtocolMatchCondition TCP `
                -NetworkProfile All `
                -ThrottleRateActionBitsPerSecond 0 `
                -DSCPAction 46 `
                -ErrorAction Stop
            
            Write-Log "QoS Policy erstellt fuer Port $($CONFIG.ServerPort)" "SUCCESS"
            $script:optimizationsApplied += "QoS Policy (DSCP 46)"
        } else {
            # Remove policy
            Remove-NetQosPolicy -Name $policyName -Confirm:$false -ErrorAction SilentlyContinue
            Write-Log "QoS Policy entfernt" "RESTORE"
        }
    } catch {
        Write-Log "QoS Policy Fehler: $_" "ERROR"
    }
}

function Set-ProcessPriority {
    param([bool]$Enable, [bool]$Silent = $false)
    try {
        $process = Get-Process -Name $CONFIG.ProcessName -ErrorAction SilentlyContinue
        if ($process) {
            if ($Enable) {
                # Only set if not already High
                if ($process.PriorityClass -ne "High") {
                    $process.PriorityClass = "High"
                    if (-not $Silent) {
                        Write-Log "Prozess-Prioritaet auf High gesetzt" "SUCCESS"
                        $script:optimizationsApplied += "Process Priority: High"
                    }
                }
            } else {
                $process.PriorityClass = "Normal"
                Write-Log "Prozess-Prioritaet auf Normal zurueckgesetzt" "RESTORE"
            }
        }
    } catch {
        if (-not $Silent) {
            Write-Log "Prozess-Prioritaet Fehler: $_" "ERROR"
        }
    }
}

function Optimize-DNSCache {
    param([bool]$Enable)
    try {
        if ($Enable) {
            # Clear old DNS cache (works on all Windows versions)
            Clear-DnsClientCache -ErrorAction SilentlyContinue
            
            # Alternative method if Clear-DnsClientCache doesn't exist
            if (-not (Get-Command Clear-DnsClientCache -ErrorAction SilentlyContinue)) {
                ipconfig /flushdns | Out-Null
            }
            
            Write-Log "DNS Cache geleert" "SUCCESS"
            $script:optimizationsApplied += "DNS Cache cleared"
        } else {
            # Clear cache on exit as well
            Clear-DnsClientCache -ErrorAction SilentlyContinue
            if (-not (Get-Command Clear-DnsClientCache -ErrorAction SilentlyContinue)) {
                ipconfig /flushdns | Out-Null
            }
            Write-Log "DNS Cache geleert (Cleanup)" "RESTORE"
        }
    } catch {
        Write-Log "DNS Cache Fehler: $_" "ERROR"
    }
}

function Set-NetworkOptimizations {
    param([bool]$Enable)
    try {
        $adapter = (Get-NetAdapter | Where-Object Status -eq 'Up' | Select-Object -First 1).Name
        if ($Enable) {
            netsh interface ipv4 set subinterface $adapter mtu=$MTU store=persistent | Out-Null
            Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces' | ForEach-Object {
                Set-ItemProperty -Path $_.PSPath -Name "TcpAckFrequency" -Value 1 -Type DWord -Force -EA 0
                Set-ItemProperty -Path $_.PSPath -Name "TCPNoDelay" -Value 1 -Type DWord -Force -EA 0
            }
            Write-Log "Basis-Netzwerkoptimierungen aktiviert (MTU: $MTU)" "SUCCESS"
        } else {
            netsh interface ipv4 set subinterface $adapter mtu=1500 store=persistent | Out-Null
            Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces' | ForEach-Object {
                Remove-ItemProperty -Path $_.PSPath -Name "TcpAckFrequency" -EA 0
                Remove-ItemProperty -Path $_.PSPath -Name "TCPNoDelay" -EA 0
            }
            Write-Log "Basis-Netzwerkoptimierungen deaktiviert" "RESTORE"
        }
    } catch {
        Write-Log "Netzwerkoptimierungen Fehler: $_" "ERROR"
    }
}

function Apply-AllOptimizations {
    Write-Log "=== Starte Optimierungen ===" "INFO"
    
    # Basis-Optimierungen (Original)
    Set-NetworkOptimizations -Enable $true
    
    # STUFE 1 Optimierungen
    Set-NetworkThrottling -Enable $true
    Set-SystemResponsiveness -Enable $true
    Set-QoSPolicy -Enable $true
    Set-ProcessPriority -Enable $true
    Optimize-DNSCache -Enable $true
    
    Write-Log "=== Alle Optimierungen angewendet ===" "SUCCESS"
}

function Remove-AllOptimizations {
    Write-Log "=== Starte Rollback ===" "INFO"
    
    # In umgekehrter Reihenfolge entfernen
    Optimize-DNSCache -Enable $false
    Set-ProcessPriority -Enable $false
    Set-QoSPolicy -Enable $false
    Set-SystemResponsiveness -Enable $false
    Set-NetworkThrottling -Enable $false
    Set-NetworkOptimizations -Enable $false
    
    Write-Log "=== Rollback abgeschlossen ===" "SUCCESS"
}

# Apply Optimizations
Apply-AllOptimizations

function Create-IconWithText {
    param([string]$text, [System.Drawing.Color]$color)
    $bitmap = New-Object System.Drawing.Bitmap 32, 32
    $g = [System.Drawing.Graphics]::FromImage($bitmap)
    $g.SmoothingMode = "AntiAlias"
    $brush = New-Object System.Drawing.SolidBrush $color
    $g.FillEllipse($brush, 2, 2, 28, 28)
    $font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
    $sf = New-Object System.Drawing.StringFormat -Property @{Alignment='Center'; LineAlignment='Center'}
    $g.DrawString($text, $font, [System.Drawing.Brushes]::White, (New-Object System.Drawing.RectangleF(0, 0, 32, 34)), $sf)
    $hIcon = $bitmap.GetHicon()
    $icon = [System.Drawing.Icon]::FromHandle($hIcon)
    $g.Dispose(); $brush.Dispose(); $font.Dispose(); $bitmap.Dispose()
    return $icon
}

# ==========================================
# 4. TRAY ICON & MENU
# ==========================================
$trayIcon = New-Object System.Windows.Forms.NotifyIcon
$trayIcon.Visible = $true
$contextMenu = New-Object System.Windows.Forms.ContextMenuStrip

# Statistics Menu Item
$menuStats = New-Object System.Windows.Forms.ToolStripMenuItem("Show Statistics")
$menuStats.Add_Click({
    $avgLat = if($script:latencyHistory.Count -gt 0){ [math]::Round(($script:latencyHistory | Measure-Object -Average).Average, 1) } else { 0 }
    $lossRate = if($script:totalChecks -gt 0){ [math]::Round(($script:failedChecks / $script:totalChecks) * 100, 2) } else { 0 }
    
    $optimizationsList = if($script:optimizationsApplied.Count -gt 0) { 
        "`n`nActive Optimizations:`n• " + ($script:optimizationsApplied -join "`n• ")
    } else { 
        "`n`nNo optimizations active" 
    }
    
    $msg = "RAGNAROK+ PINGBOOST v2.0`n" +
           "===========================`n" +
           "Current Ping: $($script:lastLatency) ms`n" +
           "Average Ping: $avgLat ms`n" +
           "Min/Max:      $($script:minLatency) / $($script:maxLatency) ms`n" +
           "Packet Loss:  $lossRate %`n" +
           "Active MTU:   $MTU" +
           $optimizationsList
    [System.Windows.Forms.MessageBox]::Show($msg, "Ragnarok+ Stats", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
})

# View Log Menu Item
$menuLog = New-Object System.Windows.Forms.ToolStripMenuItem("View Log")
$menuLog.Add_Click({
    $logFile = Join-Path $scriptPath "pingboost.log"
    if (Test-Path $logFile) {
        notepad.exe $logFile
    } else {
        [System.Windows.Forms.MessageBox]::Show("Log file not found.", "Info")
    }
})

# Exit Menu Item
$menuExit = New-Object System.Windows.Forms.ToolStripMenuItem("Exit & Reset Settings")
$menuExit.Add_Click({ 
    Remove-AllOptimizations
    $trayIcon.Visible = $false
    [System.Windows.Forms.Application]::Exit() 
})

$null = $contextMenu.Items.Add($menuStats)
$null = $contextMenu.Items.Add($menuLog)
$null = $contextMenu.Items.Add("-")  # Separator
$null = $contextMenu.Items.Add($menuExit)
$trayIcon.ContextMenuStrip = $contextMenu

# ==========================================
# 5. MONITOR LOOP
# ==========================================
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = $CONFIG.PingInterval
$timer.Add_Tick({
    if (-not (Get-Process -Name $CONFIG.ProcessName -ErrorAction SilentlyContinue)) { 
        Remove-AllOptimizations
        $trayIcon.Visible = $false
        [System.Windows.Forms.Application]::Exit()
        return
    }
    
    # Refresh process priority (in case it was changed)
    Set-ProcessPriority -Enable $true -Silent $true
    
    $script:totalChecks++
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $tcp = New-Object System.Net.Sockets.TcpClient
        $ar = $tcp.BeginConnect($CONFIG.ServerAddress, $CONFIG.ServerPort, $null, $null)
        if ($ar.AsyncWaitHandle.WaitOne(2000, $false)) {
            $tcp.EndConnect($ar); $sw.Stop()
            $lat = $sw.ElapsedMilliseconds
            
            # Update Statistics
            $script:lastLatency = $lat
            $script:latencyHistory += [double]$lat
            if ($script:latencyHistory.Count -gt $CONFIG.MaxHistorySize) { $script:latencyHistory = $script:latencyHistory[1..$CONFIG.MaxHistorySize] }
            if ($lat -lt $script:minLatency) { $script:minLatency = $lat }
            if ($lat -gt $script:maxLatency) { $script:maxLatency = $lat }

            $col = if($lat -lt 70){ [System.Drawing.Color]::Green } elseif($lat -lt 130) { [System.Drawing.Color]::Orange } else { [System.Drawing.Color]::Red }
            $disp = $lat.ToString()
            $trayIcon.Text = "R+ v2 | Ping: $lat ms"
        } else { throw "Timeout" }
    } catch { 
        $script:failedChecks++
        $col = [System.Drawing.Color]::Red; $disp = "X" 
        $trayIcon.Text = "R+ v2 | Connection Lost"
    } finally { if($tcp){$tcp.Close(); $tcp.Dispose()} }

    # Update Icon
    $old = $trayIcon.Icon
    $trayIcon.Icon = Create-IconWithText -text $disp -color $col
    if($old){ $helper::DestroyIcon($old.Handle); $old.Dispose() }
})

$timer.Start()
Write-Log "Monitoring gestartet" "INFO"
[System.Windows.Forms.Application]::Run()