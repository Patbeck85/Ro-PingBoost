# ==========================================
# 1. INITIAL SETUP
# ==========================================
$CONFIG = @{
    ServerAddress  = "138.201.124.56"
    ServerPort     = 5121
    ProcessName    = "Ragnarokplus"
    PingInterval   = 3000
    MaxHistorySize = 100
}

# Wait for Launcher Countdown (30s)
Start-Sleep -Seconds 30

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$mtuConfigFile = Join-Path $scriptPath "mtu.cfg"
$MTU = if (Test-Path $mtuConfigFile) { (Get-Content $mtuConfigFile).Trim() } else { "1500" }

# ==========================================
# 2. WAIT FOR GAME (Up to 2 Minutes)
# ==========================================
$retryCount = 0
while (-not (Get-Process -Name $CONFIG.ProcessName -ErrorAction SilentlyContinue) -and $retryCount -lt 60) {
    Start-Sleep -Seconds 2
    $retryCount++
}

if (-not (Get-Process -Name $CONFIG.ProcessName -ErrorAction SilentlyContinue)) {
    exit 
}

# ==========================================
# 3. STATS & HELPER FUNCTIONS
# ==========================================
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
$sig = '[DllImport("user32.dll", SetLastError=true)] public static extern bool DestroyIcon(IntPtr hIcon);'
$helper = Add-Type -MemberDefinition $sig -Name "IconHelper" -PassThru

# Stats Tracking Variables
$script:latencyHistory = @()
$script:totalChecks = 0
$script:failedChecks = 0
$script:minLatency = [int]::MaxValue
$script:maxLatency = 0
$script:lastLatency = 0

function Set-NetworkOptimizations {
    param([bool]$Enable)
    try {
        $adapter = (Get-NetAdapter | Where-Object Status -eq 'Up' | Select-Object -First 1).Name
        if ($Enable) {
            netsh interface ipv4 set subinterface $adapter mtu=$MTU store=persistent | Out-Null
            Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces' | ForEach-Object {
                Set-ItemProperty -Path $_.PSPath -Name "TcpAckFrequency" -Value 1 -Type DWord -Force -EA 0
                Set-ItemProperty -Path $_.PSPath -Name "TCPNoDelay" -Value 1 -Type DWord -Force -EA 0
            }
        } else {
            netsh interface ipv4 set subinterface $adapter mtu=1500 store=persistent | Out-Null
            Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces' | ForEach-Object {
                Remove-ItemProperty -Path $_.PSPath -Name "TcpAckFrequency" -EA 0
                Remove-ItemProperty -Path $_.PSPath -Name "TCPNoDelay" -EA 0
            }
        }
    } catch {}
}

function Create-IconWithText {
    param([string]$text, [System.Drawing.Color]$color)
    $bitmap = New-Object System.Drawing.Bitmap 32, 32
    $g = [System.Drawing.Graphics]::FromImage($bitmap)
    $g.SmoothingMode = "AntiAlias"
    $brush = New-Object System.Drawing.SolidBrush $color
    $g.FillEllipse($brush, 2, 2, 28, 28)
    $font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
    $sf = New-Object System.Drawing.StringFormat -Property @{Alignment='Center'; LineAlignment='Center'}
    $g.DrawString($text, $font, [System.Drawing.Brushes]::White, (New-Object System.Drawing.RectangleF(0, 0, 32, 34)), $sf)
    $hIcon = $bitmap.GetHicon()
    $icon = [System.Drawing.Icon]::FromHandle($hIcon)
    $g.Dispose(); $brush.Dispose(); $font.Dispose(); $bitmap.Dispose()
    return $icon
}

# Apply Optimizations
Set-NetworkOptimizations -Enable $true

# ==========================================
# 4. TRAY ICON & MENU
# ==========================================
$trayIcon = New-Object System.Windows.Forms.NotifyIcon
$trayIcon.Visible = $true
$contextMenu = New-Object System.Windows.Forms.ContextMenuStrip

# Statistics Menu Item
$menuStats = New-Object System.Windows.Forms.ToolStripMenuItem("Show Statistics")
$menuStats.Add_Click({
    $avgLat = if($script:latencyHistory.Count -gt 0){ [math]::Round(($script:latencyHistory | Measure-Object -Average).Average, 1) } else { 0 }
    $lossRate = if($script:totalChecks -gt 0){ [math]::Round(($script:failedChecks / $script:totalChecks) * 100, 2) } else { 0 }
    
    $msg = "RAGNAROK+ PINGBOOST`n" +
           "=====================`n" +
           "Current Ping: $($script:lastLatency) ms`n" +
           "Average Ping: $avgLat ms`n" +
           "Min/Max:      $($script:minLatency) / $($script:maxLatency) ms`n" +
           "Packet Loss:  $lossRate %`n" +
           "Active MTU:   $MTU`n`n" +
           "Status: Optimizations Applied"
    [System.Windows.Forms.MessageBox]::Show($msg, "Ragnarok+ Stats")
})

# Exit Menu Item
$menuExit = New-Object System.Windows.Forms.ToolStripMenuItem("Exit & Reset Settings")
$menuExit.Add_Click({ 
    Set-NetworkOptimizations -Enable $false
    $trayIcon.Visible = $false
    [System.Windows.Forms.Application]::Exit() 
})

$null = $contextMenu.Items.Add($menuStats)
$null = $contextMenu.Items.Add($menuExit)
$trayIcon.ContextMenuStrip = $contextMenu

# ==========================================
# 5. MONITOR LOOP
# ==========================================
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = $CONFIG.PingInterval
$timer.Add_Tick({
    if (-not (Get-Process -Name $CONFIG.ProcessName -ErrorAction SilentlyContinue)) { 
        Set-NetworkOptimizations -Enable $false
        $trayIcon.Visible = $false; [System.Windows.Forms.Application]::Exit(); return
    }
    
    $script:totalChecks++
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $tcp = New-Object System.Net.Sockets.TcpClient
        $ar = $tcp.BeginConnect($CONFIG.ServerAddress, $CONFIG.ServerPort, $null, $null)
        if ($ar.AsyncWaitHandle.WaitOne(2000, $false)) {
            $tcp.EndConnect($ar); $sw.Stop()
            $lat = $sw.ElapsedMilliseconds
            
            # Update Statistics
            $script:lastLatency = $lat
            $script:latencyHistory += [double]$lat
            if ($script:latencyHistory.Count -gt $CONFIG.MaxHistorySize) { $script:latencyHistory = $script:latencyHistory[1..$CONFIG.MaxHistorySize] }
            if ($lat -lt $script:minLatency) { $script:minLatency = $lat }
            if ($lat -gt $script:maxLatency) { $script:maxLatency = $lat }

            $col = if($lat -lt 70){ [System.Drawing.Color]::Green } elseif($lat -lt 130) { [System.Drawing.Color]::Orange } else { [System.Drawing.Color]::Red }
            $disp = $lat.ToString()
            $trayIcon.Text = "R+ | Ping: $lat ms"
        } else { throw "Timeout" }
    } catch { 
        $script:failedChecks++
        $col = [System.Drawing.Color]::Red; $disp = "X" 
        $trayIcon.Text = "R+ | Connection Lost"
    } finally { if($tcp){$tcp.Close(); $tcp.Dispose()} }

    # Update Icon
    $old = $trayIcon.Icon
    $trayIcon.Icon = Create-IconWithText -text $disp -color $col
    if($old){ $helper::DestroyIcon($old.Handle); $old.Dispose() }
})

$timer.Start()
[System.Windows.Forms.Application]::Run()