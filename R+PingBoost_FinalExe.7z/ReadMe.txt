============================================================
           RAGNAROK+ PINGBOOST - QUICKGUIDE
============================================================

⚠️ !!! WICHTIG / IMPORTANT !!! ⚠️
Aufgrund technischer Probleme mit Sonderzeichen muss die 
Original-Datei "Ragnarok+.exe" zwingend in "Ragnarokplus.exe" 
umbenannt werden!

Due to technical issues with special characters, you MUST 
rename "Ragnarok+.exe" to "Ragnarokplus.exe"!

============================================================

🚀 SETUP:
1. Rename "Ragnarok+.exe" -> "Ragnarokplus.exe".
2. Copy all tool files to the Game Folder.
3. Run 'MTU_Finder.bat' as Admin (Once).
4. Play via 'RoPlusBoost.exe'.

📈 PING COLORS:
Green  < 80ms  | Perfect
Yellow < 150ms | Okay
Red    > 150ms | Lag

------------------------------------------------------------
❤ DANKSAGUNG / SPECIAL THANKS
------------------------------------------------------------
Ein riesiges Dankeschön geht an die gesamte Community und 
alle Spieler, sowie an die Serverbetreiber und Administratoren!
Ohne eure harte Arbeit wäre diese Welt nicht möglich!

A huge thank you to the entire community and all players, 
and especially to the server owners and administrators!
None of this would be possible without your dedication!

============================================================
               ~ Enjoy the lag-free game! ~
============================================================