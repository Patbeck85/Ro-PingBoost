# Ragnarok+ Ping Monitor - System Tray Edition
# Zeigt Echtzeit-Ping zum Game-Server in der Taskleiste

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Settings File
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$settingsFile = Join-Path $scriptDir "monitor_settings.ini"

# KONFIGURATION LADEN ODER STANDARDWERTE
if (Test-Path $settingsFile) {
    $settings = Get-Content $settingsFile
    $serverAddress = $settings[0]
    $processName = $settings[1]
} else {
    # Standardwerte (können über Context-Menu geändert werden)
    $serverAddress = "138.201.124.56"
    $processName = "Ragnarokplus"
    
    # Einstellungen speichern
    @($serverAddress, $processName) | Out-File -FilePath $settingsFile -Encoding UTF8
}

$pingInterval = 2000  # Ping alle 2 Sekunden

# Tray Icon erstellen
$trayIcon = New-Object System.Windows.Forms.NotifyIcon
$trayIcon.Text = "Ragnarok+ Ping Monitor"
$trayIcon.Visible = $true

# Context Menu
$contextMenu = New-Object System.Windows.Forms.ContextMenuStrip

# Menu: Einstellungen ändern
$menuSettings = New-Object System.Windows.Forms.ToolStripMenuItem
$menuSettings.Text = "Change Server/Process"
$menuSettings.Add_Click({
    Add-Type -AssemblyName Microsoft.VisualBasic
    
    $newServer = [Microsoft.VisualBasic.Interaction]::InputBox(
        "Enter new server address or IP:",
        "Change Settings",
        $serverAddress
    )
    
    if (-not [string]::IsNullOrEmpty($newServer)) {
        $newProcess = [Microsoft.VisualBasic.Interaction]::InputBox(
            "Enter new process name (without .exe):",
            "Change Settings",
            $processName
        )
        
        if (-not [string]::IsNullOrEmpty($newProcess)) {
            $script:serverAddress = $newServer
            $script:processName = $newProcess
            @($newServer, $newProcess) | Out-File -FilePath $settingsFile -Encoding UTF8 -Force
            [System.Windows.Forms.MessageBox]::Show("Settings updated! Changes will take effect on next restart.", "Success", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        }
    }
})
$contextMenu.Items.Add($menuSettings) | Out-Null

# Separator
$contextMenu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null

# Menu: Exit
$menuExit = New-Object System.Windows.Forms.ToolStripMenuItem
$menuExit.Text = "Exit Monitor"
$menuExit.Add_Click({
    $trayIcon.Visible = $false
    $trayIcon.Dispose()
    [System.Windows.Forms.Application]::Exit()
})
$contextMenu.Items.Add($menuExit) | Out-Null
$trayIcon.ContextMenuStrip = $contextMenu

# Statistiken
$pingHistory = @()
$maxHistory = 20
$lastPing = 0
$jitterHistory = @()
$totalPings = 0
$lostPings = 0

# Funktion: Icon mit Text erstellen
function Create-IconWithText {
    param([string]$text, [System.Drawing.Color]$color)
    
    $bitmap = New-Object System.Drawing.Bitmap 32, 32
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.Clear([System.Drawing.Color]::Transparent)
    
    # Hintergrund-Kreis
    $brush = New-Object System.Drawing.SolidBrush $color
    $graphics.FillEllipse($brush, 2, 2, 28, 28)
    
    # Text
    $font = New-Object System.Drawing.Font "Arial", 10, [System.Drawing.FontStyle]::Bold
    $textBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::White)
    $format = New-Object System.Drawing.StringFormat
    $format.Alignment = [System.Drawing.StringAlignment]::Center
    $format.LineAlignment = [System.Drawing.StringAlignment]::Center
    
    $graphics.DrawString($text, $font, $textBrush, 16, 16, $format)
    
    $graphics.Dispose()
    $brush.Dispose()
    $textBrush.Dispose()
    $font.Dispose()
    
    $icon = [System.Drawing.Icon]::FromHandle($bitmap.GetHicon())
    return $icon
}

# Funktion: Ping ausführen
function Get-PingResult {
    param([string]$target)
    
    try {
        $ping = Test-Connection -ComputerName $target -Count 1 -ErrorAction Stop
        return [int]$ping.ResponseTime
    } catch {
        return -1
    }
}

# Funktion: Farbe basierend auf Ping, Jitter UND Paketverlust
function Get-PingColor {
    param([int]$ping, [int]$jitter, [double]$packetLoss)
    
    # Paketverlust hat höchste Priorität
    if ($ping -lt 0 -or $packetLoss -gt 10) {
        return [System.Drawing.Color]::FromArgb(200, 50, 50)  # Rot - Keine Verbindung oder >10% Loss
    } elseif ($packetLoss -gt 5) {
        return [System.Drawing.Color]::FromArgb(255, 100, 0)   # Orange - 5-10% Loss (kritisch)
    } elseif ($packetLoss -gt 2) {
        return [System.Drawing.Color]::FromArgb(255, 200, 0)   # Gelb - 2-5% Loss (problematisch)
    } elseif ($jitter -gt 30) {
        return [System.Drawing.Color]::FromArgb(255, 100, 0)   # Orange - Hoher Jitter (instabil)
    } elseif ($jitter -gt 15) {
        return [System.Drawing.Color]::FromArgb(255, 200, 0)   # Gelb - Mittlerer Jitter
    } elseif ($ping -lt 50) {
        return [System.Drawing.Color]::FromArgb(50, 200, 50)  # Grün - Exzellent
    } elseif ($ping -lt 100) {
        return [System.Drawing.Color]::FromArgb(100, 200, 50)  # Hellgrün - Gut
    } elseif ($ping -lt 150) {
        return [System.Drawing.Color]::FromArgb(255, 200, 0)   # Gelb - Mittel
    } else {
        return [System.Drawing.Color]::FromArgb(255, 100, 0)   # Orange - Schlecht
    }
}

# Timer für Ping-Updates
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = $pingInterval
$timer.Add_Tick({
    # Prüfen ob Game noch läuft
    $gameProcess = Get-Process -Name $processName -ErrorAction SilentlyContinue
    if (-not $gameProcess) {
        Write-Host "Game closed - stopping monitor"
        $timer.Stop()
        $trayIcon.Visible = $false
        $trayIcon.Dispose()
        [System.Windows.Forms.Application]::Exit()
        return
    }
    
    # Ping ausführen
    $ping = Get-PingResult -target $serverAddress
    
    # Paketverlust tracken
    $totalPings++
    if ($ping -lt 0) {
        $lostPings++
    }
    $packetLoss = if ($totalPings -gt 0) { [math]::Round(($lostPings / $totalPings) * 100, 2) } else { 0 }
    
    # Jitter berechnen (Differenz zum letzten Ping)
    $jitter = 0
    if ($lastPing -gt 0 -and $ping -gt 0) {
        $jitter = [Math]::Abs($ping - $lastPing)
        $jitterHistory += $jitter
        if ($jitterHistory.Count -gt $maxHistory) {
            $jitterHistory = $jitterHistory[-$maxHistory..-1]
        }
    }
    $lastPing = $ping
    
    # Statistiken aktualisieren
    if ($ping -gt 0) {
        $pingHistory += $ping
        if ($pingHistory.Count -gt $maxHistory) {
            $pingHistory = $pingHistory[-$maxHistory..-1]
        }
    }
    
    # Icon und Text aktualisieren
    if ($ping -lt 0) {
        $displayText = "X"
        $tooltipText = "Ragnarok+ Monitor`n━━━━━━━━━━━━━━━`nServer: $serverAddress`nStatus: NO CONNECTION`n`nPacket Loss: ${packetLoss}% (${lostPings}/${totalPings})"
    } else {
        $displayText = if ($ping -lt 100) { "$ping" } else { "99+" }
        $avg = if ($pingHistory.Count -gt 0) { [int]($pingHistory | Measure-Object -Average).Average } else { 0 }
        $min = if ($pingHistory.Count -gt 0) { ($pingHistory | Measure-Object -Minimum).Minimum } else { 0 }
        $max = if ($pingHistory.Count -gt 0) { ($pingHistory | Measure-Object -Maximum).Maximum } else { 0 }
        
        $avgJitter = if ($jitterHistory.Count -gt 0) { [int]($jitterHistory | Measure-Object -Average).Average } else { 0 }
        $maxJitter = if ($jitterHistory.Count -gt 0) { ($jitterHistory | Measure-Object -Maximum).Maximum } else { 0 }
        
        # Qualitäts-Indikator
        $quality = if ($packetLoss -eq 0 -and $avgJitter -lt 10 -and $avg -lt 50) { "★ EXCELLENT ★" } 
                   elseif ($packetLoss -lt 2 -and $avgJitter -lt 20) { "Good" }
                   elseif ($packetLoss -lt 5) { "Fair" }
                   else { "⚠ POOR ⚠" }
        
        $tooltipText = "Ragnarok+ Monitor`n━━━━━━━━━━━━━━━`nServer: $serverAddress`nQuality: $quality`n`nPing:`n  Current: ${ping}ms`n  Average: ${avg}ms`n  Min: ${min}ms / Max: ${max}ms`n`nJitter:`n  Current: ${jitter}ms`n  Average: ${avgJitter}ms`n  Max: ${maxJitter}ms`n`nPacket Loss:`n  ${packetLoss}% (${lostPings}/${totalPings} lost)"
    }
    
    $color = Get-PingColor -ping $ping -jitter $jitter -packetLoss $packetLoss
    $newIcon = Create-IconWithText -text $displayText -color $color
    
    if ($trayIcon.Icon) {
        $trayIcon.Icon.Dispose()
    }
    $trayIcon.Icon = $newIcon
    $trayIcon.Text = $tooltipText
})

# Initial Icon
$initialIcon = Create-IconWithText -text "..." -color ([System.Drawing.Color]::FromArgb(100, 100, 100))
$trayIcon.Icon = $initialIcon

# Timer starten
$timer.Start()

# Balloon Tip anzeigen
$trayIcon.BalloonTipTitle = "Ragnarok+ Ping Monitor"
$trayIcon.BalloonTipText = "Monitoring server: $serverAddress"
$trayIcon.ShowBalloonTip(3000)

# Application Loop
[System.Windows.Forms.Application]::Run()

# Cleanup
$timer.Dispose()
$trayIcon.Dispose()