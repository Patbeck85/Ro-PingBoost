# 🎮 Ragnarok+ PingBoost

**Network Optimization Tool for Ragnarok Online**

Reduces ping through intelligent network optimizations.

---

## ✨ Features

### 🚀 Network Optimizations
- **Automatic MTU Detection** - Finds optimal MTU value (1400-1472)
- **TCP Nagle's Algorithm disabled** - Reduces latency via TcpAckFrequency=1 and TCPNoDelay=1
- **Persistent MTU setting** - Remains active until reset

### 📊 Real-time Monitoring
- **Ping display in System Tray** with colored icon
- **Color coding:**
  - 🟢 Green = Excellent (< 50ms)
  - 🟡 Orange = Good (50-100ms)
  - 🔴 Red = Connection problem
- **Auto-close** when game is closed

### 🔒 Security
- **Automatic Rollback** - All changes reversed after gaming
- **MTU reset to 1500** - Default value restored
- **Registry entries removed** - TcpAckFrequency and TCPNoDelay deleted

---

## 📦 Installation

### Requirements
- Windows 10/11
- Administrator rights
- PowerShell
- Ragnarok Online Client

### Setup
1. **Download files:**
   - `R+PingBoost.bat`
   - `R+PingBoost.vbs`
   - `monitor.ps1`

2. **Copy all three files to the same folder** (e.g., your Ragnarok folder)

3. **Important:** BAT file must be run as **Administrator**!

---

## 🚀 Usage

### Starting
```
Right-click → R+PingBoost.bat → Run as Administrator
```

**The BAT file:**
- Checks if all files are present
- Starts the ping monitor in the background
- Starts the VBScript for optimizations and game

### First Start
1. **MTU test runs automatically** (10-15 seconds)
   - Tests MTU values from 1472 to 1400
   - Result saved in `R+_settings.ini`

2. **Optimizations applied:**
   - MTU set to optimal value
   - Nagle's Algorithm disabled
   - Network adapter detected and configured

3. **Game starts automatically**
   - Ragnarokplus.exe is launched

4. **Ping monitor appears in System Tray**
   - Shows current ping every 3 seconds
   - Tooltip shows details on hover

5. **Status message appears:**
   ```
   RAGNAROK+ PINGBOOST ACTIVE!
   
   MTU: 1472
   Nagle: Optimized
   
   Click OK after playing to reset settings.
   ```

### During Gaming
- **Hover over tray icon** shows current ping value
- Monitor runs automatically in background
- Icon turns red on connection problems

### Shutdown
1. **Close game**
2. **Click OK** in PingBoost message
3. **All optimizations automatically reversed**
4. **Confirmation appears:**
   ```
   All network settings have been reset to default.
   
   MTU: 1500
   TCP optimizations: Removed
   ```
5. **Monitor closes automatically**

---

## ⚙️ Configuration

### Change Server IP
**File:** `monitor.ps1`  
**Line 9:**
```powershell
$serverAddress = "138.201.124.56"  # <--- Enter your server IP here
```

### Change Game Exe
**Option 1:** Edit file `R+_settings.ini` (line 1)  
**Option 2:** Delete file `R+_settings.ini` and restart script

### Manually Change MTU Value
**Edit file:** `R+_settings.ini` (line 2)
```
Ragnarokplus.exe
1472
```

### Retest MTU
**Delete file `R+_settings.ini`** and restart script - test runs automatically

---

## 📁 Created Files

| File | Description |
|------|-------------|
| `R+_settings.ini` | Saved settings (Game-Exe + MTU value) |
| `mtu.tmp` | Temporary file during MTU test (auto-deleted) |
| `ping-monitor-log.txt` | Log file of ping monitor |

---

## 🔧 What Gets Optimized?

### Network Parameters
```
Registry: HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces
├─ TcpAckFrequency = 1     (disables ACK delay)
├─ TCPNoDelay = 1          (disables Nagle's Algorithm)
└─ MTU = 1400-1472         (optimized for gaming)
```

### On Reset (after gaming)
```
├─ TcpAckFrequency = Deleted
├─ TCPNoDelay = Deleted  
└─ MTU = 1500 (default)
```

---

## 🐛 Troubleshooting

### BAT file shows error "monitor.ps1 not found"
**Solution:** All 3 files must be in the same folder
- `R+PingBoost.bat`
- `R+PingBoost.vbs`
- `monitor.ps1`

### BAT file shows error "R+PingBoost.vbs not found"
**Solution:** Check filename - must be exactly `R+PingBoost.vbs`

### Script won't start
**Solution:** Run as Administrator
- Right-click on BAT file
- Select "Run as Administrator"

### Game not found
**Check:**
- Is `Ragnarokplus.exe` in the same folder?
- Or: Delete `R+_settings.ini` and enter correct name

### Monitor shows "X" instead of ping
**Causes:**
- Server is offline
- Firewall blocks ICMP (ping)
- Wrong server IP in `monitor.ps1`

**Solution:**
- Check server IP in `monitor.ps1` (line 9)
- Check firewall settings

### Monitor doesn't start
**Check `ping-monitor-log.txt`:**
- Shows if process was found
- Shows wait time (max. 60 seconds)

**Solution:**
- Check game name in `R+_settings.ini`
- Check log file for errors

### Optimizations don't work
**Check:**
- Script started as Administrator?
- Network adapter detected correctly? (shown in VBS)

---

## 🎯 Recommended Values

### MTU Values
- **1500** - Standard Ethernet
- **1492** - PPPoE DSL connections  
- **1472** - Optimal for most connections
- **1460** - Conservative for gaming
- **1400** - For unstable connections

### Ping Quality
- **< 50ms** - Excellent (Icon: green)
- **50-100ms** - Good (Icon: orange)
- **> 100ms** - Problematic (Icon: orange/red)
- **No connection** - X displayed (Icon: red)

---

## ❗ Important Notes

### ⚠️ Administrator Rights Required
The script **MUST** be run as Administrator!

### 🔄 Automatic Rollback
All changes are automatically reversed on shutdown.

### 🔒 Security
- No permanent system changes
- All values restored after gaming
- System remains in default state

### 📝 Monitor Log
The file `ping-monitor-log.txt` shows:
- When monitor was started
- If process was found
- When monitor was closed

---

## 📜 License

This tool is free and open-source.

**Use at your own risk!** The script changes system settings. Although all changes are automatically reversed, use responsibly.

---

## 🙏 Credits

Developed for the Ragnarok Online Community.

**Have fun playing with optimized ping!** 🎮✨