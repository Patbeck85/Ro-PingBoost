# 🎮 Ragnarok+ PingBoost

**Netzwerk-Optimierungs-Tool für Ragnarok Online**

Reduziert Ping durch intelligente Netzwerk-Optimierungen.

---

## ✨ Features

### 🚀 Netzwerk-Optimierungen
- **Automatische MTU-Erkennung** - Findet den optimalen MTU-Wert (1400-1472)
- **TCP Nagle's Algorithm deaktiviert** - Reduziert Latenz durch TcpAckFrequency=1 und TCPNoDelay=1
- **Persistente MTU-Einstellung** - Bleibt aktiv bis zum Reset

### 📊 Echtzeit-Monitoring
- **Ping-Anzeige im System Tray** mit farbigem Icon
- **Farbcodierung:**
  - 🟢 Grün = Exzellent (< 50ms)
  - 🟡 Orange = Gut (50-100ms)
  - 🔴 Rot = Verbindungsproblem
- **Automatische Beendigung** wenn das Spiel geschlossen wird

### 🔒 Sicherheit
- **Automatischer Rollback** - Alle Änderungen werden nach Spielende rückgängig gemacht
- **MTU zurück auf 1500** - Standard-Wert wird wiederhergestellt
- **Registry-Einträge entfernt** - TcpAckFrequency und TCPNoDelay werden gelöscht

---

## 📦 Installation

### Voraussetzungen
- Windows 10/11
- Administrator-Rechte
- PowerShell
- Ragnarok Online Client

### Setup
1. **Dateien herunterladen:**
   - `R+PingBoost.bat`
   - `R+PingBoost.vbs`
   - `monitor.ps1`

2. **Alle drei Dateien in den gleichen Ordner kopieren** (z.B. in deinen Ragnarok-Ordner)

3. **Wichtig:** BAT-Datei muss als **Administrator** ausgeführt werden!

---

## 🚀 Verwendung

### Starten
```
Rechtsklick → R+PingBoost.bat → Als Administrator ausführen
```

**Die BAT-Datei:**
- Prüft ob alle Dateien vorhanden sind
- Startet den Ping-Monitor im Hintergrund
- Startet das VBScript für Optimierungen und Game

### Beim ersten Start
1. **MTU-Test läuft automatisch** (10-15 Sekunden)
   - Testet MTU-Werte von 1472 bis 1400
   - Ergebnis wird in `R+_settings.ini` gespeichert

2. **Optimierungen werden angewendet:**
   - MTU auf optimalen Wert gesetzt
   - Nagle's Algorithm deaktiviert
   - Netzwerk-Adapter erkannt und konfiguriert

3. **Game startet automatisch**
   - Ragnarokplus.exe wird gestartet

4. **Ping-Monitor erscheint im System Tray**
   - Zeigt aktuellen Ping alle 3 Sekunden
   - Tooltip zeigt Details beim Hovern

5. **Status-Meldung erscheint:**
   ```
   RAGNAROK+ PINGBOOST ACTIVE!
   
   MTU: 1472
   Nagle: Optimized
   
   Click OK after playing to reset settings.
   ```

### Während des Spielens
- **Hover über Tray-Icon** zeigt aktuellen Ping-Wert
- Monitor läuft automatisch im Hintergrund
- Bei Verbindungsproblemen wird Icon rot

### Beenden
1. **Game schließen**
2. **OK klicken** in der PingBoost-Meldung
3. **Alle Optimierungen werden automatisch rückgängig gemacht**
4. **Bestätigung erscheint:**
   ```
   All network settings have been reset to default.
   
   MTU: 1500
   TCP optimizations: Removed
   ```
5. **Monitor wird automatisch beendet**

---

## ⚙️ Konfiguration

### Server-IP ändern
**Datei:** `monitor.ps1`  
**Zeile 9:**
```powershell
$serverAddress = "138.201.124.56"  # <--- Hier deine Server-IP eintragen
```

### Game-Exe ändern
**Option 1:** Datei `R+_settings.ini` bearbeiten (Zeile 1)  
**Option 2:** Datei `R+_settings.ini` löschen und Script neu starten

### MTU-Wert manuell ändern
**Datei:** `R+_settings.ini` bearbeiten (Zeile 2)
```
Ragnarokplus.exe
1472
```

### MTU neu testen
**Datei `R+_settings.ini` löschen** und Script neu starten - Test läuft automatisch

---

## 📁 Erstellte Dateien

| Datei | Beschreibung |
|-------|-------------|
| `R+_settings.ini` | Gespeicherte Einstellungen (Game-Exe + MTU-Wert) |
| `mtu.tmp` | Temporäre Datei beim MTU-Test (wird automatisch gelöscht) |
| `ping-monitor-log.txt` | Log-Datei des Ping-Monitors |

---

## 🔧 Was wird optimiert?

### Netzwerk-Parameter
```
Registry: HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces
├─ TcpAckFrequency = 1     (deaktiviert ACK-Verzögerung)
├─ TCPNoDelay = 1          (deaktiviert Nagle's Algorithm)
└─ MTU = 1400-1472         (optimiert für Gaming)
```

### Beim Reset (nach Spielende)
```
├─ TcpAckFrequency = Gelöscht
├─ TCPNoDelay = Gelöscht  
└─ MTU = 1500 (Standard)
```

---

## 🐛 Troubleshooting

### BAT-Datei zeigt Fehler "monitor.ps1 nicht gefunden"
**Lösung:** Alle 3 Dateien müssen im gleichen Ordner sein
- `R+PingBoost.bat`
- `R+PingBoost.vbs`
- `monitor.ps1`

### BAT-Datei zeigt Fehler "R+PingBoost.vbs nicht gefunden"
**Lösung:** Prüfe Dateinamen - muss exakt `R+PingBoost.vbs` heißen

### Script startet nicht
**Lösung:** Als Administrator ausführen
- Rechtsklick auf BAT-Datei
- "Als Administrator ausführen" wählen

### Game wird nicht gefunden
**Prüfe:**
- Ist `Ragnarokplus.exe` im gleichen Ordner?
- Oder: `R+_settings.ini` löschen und korrekten Namen eingeben

### Monitor zeigt "X" statt Ping
**Ursachen:**
- Server ist offline
- Firewall blockiert ICMP (Ping)
- Falsche Server-IP in `monitor.ps1`

**Lösung:**
- Server-IP in `monitor.ps1` (Zeile 9) prüfen
- Firewall-Einstellungen überprüfen

### Monitor startet nicht
**Prüfe `ping-monitor-log.txt`:**
- Zeigt ob Prozess gefunden wurde
- Zeigt Wartezeit (max. 60 Sekunden)

**Lösung:**
- Game-Namen in `R+_settings.ini` prüfen
- Log-Datei auf Fehler überprüfen

### Optimierungen greifen nicht
**Prüfe:**
- Script als Administrator gestartet?
- Netzwerk-Adapter richtig erkannt? (steht in VBS)

---

## 🎯 Empfohlene Werte

### MTU-Werte
- **1500** - Standard Ethernet
- **1492** - PPPoE DSL-Verbindungen  
- **1472** - Optimal für die meisten Verbindungen
- **1460** - Konservativ für Gaming
- **1400** - Für instabile Verbindungen

### Ping-Qualität
- **< 50ms** - Exzellent (Icon: grün)
- **50-100ms** - Gut (Icon: orange)
- **> 100ms** - Problematisch (Icon: orange/rot)
- **Keine Verbindung** - X angezeigt (Icon: rot)

---

## ❗ Wichtige Hinweise

### ⚠️ Administrator-Rechte erforderlich
Das Script **MUSS** als Administrator ausgeführt werden!

### 🔄 Automatischer Rollback
Alle Änderungen werden automatisch rückgängig gemacht beim Beenden.

### 🔒 Sicherheit
- Keine permanenten Systemänderungen
- Alle Werte werden nach Spielende wiederhergestellt
- System bleibt im Standardzustand

### 📝 Monitor-Log
Die Datei `ping-monitor-log.txt` zeigt:
- Wann Monitor gestartet wurde
- Ob Prozess gefunden wurde
- Wann Monitor beendet wurde

---

## 📜 Lizenz

Dieses Tool ist kostenlos und open-source.

**Nutzung auf eigene Gefahr!** Das Script ändert Systemeinstellungen. Auch wenn alle Änderungen automatisch rückgängig gemacht werden, nutze es verantwortungsvoll.

---

## 🙏 Credits

Entwickelt für die Ragnarok Online Community.

**Viel Spaß beim Spielen mit optimiertem Ping!** 🎮✨