# Log-Datei im gleichen Ordner wie das Skript erstellen
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$logFile = Join-Path $scriptPath "ping-monitor-log.txt"
Start-Transcript -Path $logFile -Append

Write-Host "Script gestartet um $(Get-Date)"
Write-Host "Log-Datei: $logFile"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$signature = '[DllImport("user32.dll", SetLastError=true)] public static extern bool DestroyIcon(IntPtr hIcon);'
$helper = Add-Type -MemberDefinition $signature -Name "IconHelper" -PassThru
$serverAddress = "138.201.124.56"
$processName = "Ragnarokplus"

# Wartet bis zu 60 Sek auf das Spiel
Write-Host "Warte auf Prozess '$processName'..."
$waiting = 0
while (-not (Get-Process -Name $processName -ErrorAction SilentlyContinue) -and $waiting -lt 60) {
    Start-Sleep -Seconds 1
    $waiting++
    if ($waiting % 10 -eq 0) {
        Write-Host "Warte seit $waiting Sekunden..."
    }
}

if (-not (Get-Process -Name $processName -ErrorAction SilentlyContinue)) { 
    Write-Host "Prozess '$processName' nicht gefunden nach $waiting Sekunden. Beende Script."
    Stop-Transcript
    exit 
}

Write-Host "Prozess '$processName' gefunden! Starte Ping-Monitor..."

$trayIcon = New-Object System.Windows.Forms.NotifyIcon
$trayIcon.Visible = $true

function Create-IconWithText {
    param([string]$text, [System.Drawing.Color]$color)
    $bitmap = New-Object System.Drawing.Bitmap 32, 32
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $brush = New-Object System.Drawing.SolidBrush $color
    $graphics.FillEllipse($brush, 2, 2, 28, 28)
    $font = New-Object System.Drawing.Font "Segoe UI", 12, [System.Drawing.FontStyle]::Bold
    $sf = New-Object System.Drawing.StringFormat -Property @{Alignment='Center';LineAlignment='Center'}
    $graphics.DrawString($text, $font, [System.Drawing.Brushes]::White, (New-Object System.Drawing.RectangleF(0, 0, 32, 34)), $sf)
    $hIcon = $bitmap.GetHicon()
    $icon = [System.Drawing.Icon]::FromHandle($hIcon)
    $graphics.Dispose(); $brush.Dispose(); $font.Dispose(); $bitmap.Dispose()
    return $icon
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 3000
$timer.Add_Tick({
    if (-not (Get-Process -Name $processName -ErrorAction SilentlyContinue)) { 
        Write-Host "Prozess beendet. Schließe Ping-Monitor..."
        $trayIcon.Visible = $false; $trayIcon.Dispose(); 
        Stop-Transcript
        [System.Windows.Forms.Application]::Exit() 
    }
    
    $pingProvider = New-Object System.Net.NetworkInformation.Ping
    try {
        $reply = $pingProvider.Send($serverAddress, 1000)
        if ($reply.Status -eq "Success") {
            $avgPing = $reply.RoundtripTime
            $color = if ($avgPing -lt 50) { [System.Drawing.Color]::Green } else { [System.Drawing.Color]::Orange }
            $disp = [Math]::Round($avgPing).ToString()
        } else {
            $disp = "X"; $color = [System.Drawing.Color]::Red
        }
    } catch {
        $disp = "X"; $color = [System.Drawing.Color]::Red
    }
    $oldIcon = $trayIcon.Icon
    $trayIcon.Icon = Create-IconWithText -text $disp -color $color
    $trayIcon.Text = "Ping: $disp ms"
    if ($oldIcon) { $helper::DestroyIcon($oldIcon.Handle); $oldIcon.Dispose() }
})
$timer.Start()

Write-Host "Ping-Monitor läuft. Überwache Server: $serverAddress"
[System.Windows.Forms.Application]::Run()